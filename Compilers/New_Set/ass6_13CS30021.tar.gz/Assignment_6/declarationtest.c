//Function Declaration
double func(int a,int b);
//Main Function
int main()
{
    int i, j;
    int k;
    int a = 15;
    int b = a+8;
    char *p2char, ch='c';
    double *d0, d1;
    double d = 6.9;
    int arrint[10];
    double arrdbl[3][4], dbl_num;
    int **ptr2ptr2int;
    return a;
}
//Function Definition
double func(int a,int b)
{
    int x = 9;
    double y = x;
    return y;
}
