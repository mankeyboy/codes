int main()
{
	int i1,i2,i3;
	readi(&i1);
	readi(&i2);
	i3 = i1+i2;
	printi(i3);
	return 0;
}