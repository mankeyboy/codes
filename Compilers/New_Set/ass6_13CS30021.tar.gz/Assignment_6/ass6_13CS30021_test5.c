int main()
{
	int *ptr,a;
	a = 16;
	prints("Before\t");
	a = &b;
	printi(a);
      *a = 5;
	prints("\nAfter\t");
	printi(b);
	return 0;
}