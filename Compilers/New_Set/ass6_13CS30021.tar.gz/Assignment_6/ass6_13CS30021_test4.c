int main()
{
	int a=0;
	char b,c;
	b = '1';
	c = 'A';
	if(b<=c)
	{
		a--;
	}
	else
	{
		a++;
	}
	printi(a);
	return 0;
}